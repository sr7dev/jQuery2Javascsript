/*Slider Script*/


;(function ( $ ) {
    'use strict';

    $( window ).ready(function() {

        var $slider_container = $(".et_pb_slide .et_pb_container.clearfix");
        /*[BEGIN-ADD][STG:Bojana 5/20/2019] https://www.bugherd.com/projects/163588/tasks/394   */
        $slider_container.css("height", "auto");
        /*[END-ADD][STG:Bojana 5/20/2019] https://www.bugherd.com/projects/163588/tasks/394   */


    });
})( jQuery );


/*Slider Script*/


/*Tabs Script*/

;(function ( $ ) {
    'use strict';

    $( window ).ready(function() {

        var checkCursorOverDiviTabTimer = 0,
            checkDiviTabElem;


// Enable Divi Toggle with hover
        $('.et_pb_toggle').on( 'mouseenter', function(e) {
            $( this ).children('.et_pb_toggle_title').trigger( "click" );
        });

// Enable Divi Tabs with hover
        $('.et_pb_tabs .et_pb_tabs_controls > [class^="et_pb_tab_"]').on( 'mouseenter', function(e) {

            if ( ! $( this ).hasClass('et_pb_tab_active') ) {

                checkDiviTabElem = $( this );
            }
            else {
                checkDiviTabElem = false;
            }
        });

        function checkDiviTab() {

            if ( checkDiviTabElem ) {

                if ( ! checkDiviTabElem.parent().hasClass('et_pb_tab_active') ) {

                    checkDiviTabElem.first('a').trigger( "click" );
                }
            }

            checkCursorOverDiviTabTimer = setTimeout( checkDiviTab, 150 );
        }
        checkDiviTab();
    });

})( jQuery );

/*Tabs Script*/


/*Mobile scrolling Script*/

jQuery(document).ready(function($) {

    var lastScrollTop = 0;
    $(window).scroll(function(event){
        var st = $(this).scrollTop();
        if (st > lastScrollTop){

            $('.TopSection').addClass('hide');
            $("h2.et_pb_slide_title").addClass('top');
            $(".et-pb-controllers").addClass("top-controllers");
            $(".logo_container img#logo").addClass("non-text");
            $("body").addClass("hero-scrolling");
        } else {
            $('.TopSection').removeClass('hide');
            $("h2.et_pb_slide_title").removeClass('top');
            $(".et-pb-controllers").removeClass("top-controllers");
            $(".logo_container img#logo").removeClass("non-text");
            $("body").removeClass("hero-scrolling");

        }  if (st = lastScrollTop){

            $('.TopSection').removeClass('hide');
            $("h2.et_pb_slide_title").removeClass('top');
            $(".et-pb-controllers").removeClass("top-controllers");
            $(".logo_container img#logo").removeClass("non-text");
            $("body").removeClass("hero-scrolling");


        }

        lastScrollTop = st;
    });

});


/*Mobile scrolling Script*/

;(function ( $ ) {
'use strict';
   $(document).ready( function() {
  /*[BEGIN-ADD][STG:Bojana 5/24/2019] https://www.bugherd.com/projects/163588/tasks/482*/
   var $nooffer_tab = $("li.et_pb_tab_5");  
   $nooffer_tab.addClass("nooffer");
     
   function set_nooffer_tab($target_selector)
    {
      var  $target_tab_element = $($target_selector);
      $target_tab_element.addClass("nooffer");
    }
  /*[END-ADD][STG:Bojana 5/24/2019] https://www.bugherd.com/projects/163588/tasks/482*/
  /*[BEGIN-ADD][STG:Bojana 5/20/2019] https://www.bugherd.com/projects/163588/tasks/399*/
/*[BEGIN-UPDATE][STG:Bojana 5/20/2019] https://www.bugherd.com/projects/163588/tasks/399*/     
  var $nooffer_section_element = $(".et_pb_tab_5 .pbe-li-sc .et_pb_section");
/*[END-UPDATE][STG:Bojana 5/20/2019] https://www.bugherd.com/projects/163588/tasks/455*/     
   $nooffer_section_element.parents(".et_pb_tab_content").css("background-color", "#e8e6e4");
   $nooffer_section_element.parents(".et_pb_section").css("height", "900px");
   $nooffer_section_element.css("height", "900px");
   /*[END-ADD][STG:Bojana 5/20/2019] https://www.bugherd.com/projects/163588/tasks/399*/     
     
  function set_nooffer_section($target_section_element)
  {
  
    $target_section_element.html($nooffer_section_element.html());
    
    $target_section_element.css("display", "flex");
		$target_section_element.css("flex-direction", "column");
    $target_section_element.css("background-color", "#e8e6e4");
    /*[BEGIN-ADD][STG:Bojana 5/20/2019] https://www.bugherd.com/projects/163588/tasks/399*/
    $target_section_element.css("height", "900px");
    /*[END-ADD][STG:Bojana 5/20/2019] https://www.bugherd.com/projects/163588/tasks/399*/
     $target_section_element.parents(".et_pb_tab_content").css("background-color", "#e8e6e4");    
    /*$target_section_element.css();*/
  }
 
     
 /*[BEGIN-ADD][STG:Bojana 5/10/2019] */
  var $target_dental_element = $(".TabSection .leadresult.dental_plan") ;
  var $source_dental_element = $(".LEADAPIRESULT .leadresult.dental_plan");
  if ($source_dental_element.length > 0)
  {
      $target_dental_element.html($source_dental_element.html());
  }
  else
  {
     var $dental_plan_section_element = $(".TabSection.dental_plan");
     set_nooffer_section($dental_plan_section_element);
  /*[BEGIN-ADD][STG:Bojana 5/24/2019] https://www.bugherd.com/projects/163588/tasks/482*/    
     set_nooffer_tab(".et_pb_tab_4");
  /*[BEGIN-ADD][STG:Bojana 5/24/2019] https://www.bugherd.com/projects/163588/tasks/482*/    
  }
     
  var $target_short_term_element = $(".TabSection .leadresult.short_term_health") ;
  var $source_short_term_element = $(".LEADAPIRESULT .leadresult.short_term_health");
  console.log("shorterm_elementment", $source_short_term_element);
  if ($source_short_term_element.length > 0)
  {
   $target_short_term_element.html($source_short_term_element.html());
  }    
  else
  {
     var $short_term_section_element = $(".TabSection.short_term_health");
     set_nooffer_section($short_term_section_element);
/*[BEGIN-ADD][STG:Bojana 5/24/2019] https://www.bugherd.com/projects/163588/tasks/482*/    
     set_nooffer_tab(".et_pb_tab_1");
/*[BEGIN-ADD][STG:Bojana 5/24/2019] https://www.bugherd.com/projects/163588/tasks/482*/    
  }
     
  var $target_rx_price_element = $(".TabSection .leadresult.rx_price") ;
  var $source_rx_price_element = $(".LEADAPIRESULT .leadresult.rx_price");
  if ($source_rx_price_element.length > 0)
  {
   	$target_rx_price_element.html($source_rx_price_element.html());
  }
  else
  {
     var $rx_section_element = $(".TabSection.rx_price");
     set_nooffer_section($rx_section_element);
/*[BEGIN-ADD][STG:Bojana 5/24/2019] https://www.bugherd.com/projects/163588/tasks/482*/    
     set_nooffer_tab(".et_pb_tab_3");
/*[BEGIN-ADD][STG:Bojana 5/24/2019] https://www.bugherd.com/projects/163588/tasks/482*/      
  }

     
  var $target_health_insurance_element = $(".TabSection .leadresult.health_insurance") ;
  var $source_health_insurance_element = $(".LEADAPIRESULT .leadresult.health_insurance");
  if ($source_health_insurance_element.length > 0){
      $target_health_insurance_element.html($source_health_insurance_element.html());
  }
  else
  {
     var $health_insurance_section_element = $(".TabSection.health_insurance");
     set_nooffer_section($health_insurance_section_element);  
/*[BEGIN-ADD][STG:Bojana 5/24/2019] https://www.bugherd.com/projects/163588/tasks/482*/    
     set_nooffer_tab(".et_pb_tab_0");
/*[END-ADD][STG:Bojana 5/24/2019] https://www.bugherd.com/projects/163588/tasks/482*/      
      
  }
/*[BEGIN-ADD][STG:Bojana 6/6/2019] https://gitlab.com/medicalrecords/medicalrecords-web/issues/32*/       
  var $target_medicare_element = $(".TabSection .leadresult.medicare") ;
  var $source_medicare_element = $(".LEADAPIRESULT .leadresult.medicare");
  if ($source_medicare_element.length > 0){
      $target_medicare_element.html($source_medicare_element.html());
  }
  else
  {
     var $medicare_section_element = $(".TabSection.medicare");
     set_nooffer_section($medicare_section_element);  
/*[BEGIN-ADD][STG:Bojana 6/6/2019] https://www.bugherd.com/projects/163588/tasks/482*/    
     set_nooffer_tab(".et_pb_tab_2");
/*[BEGIN-ADD][STG:Bojana 6/6/2019] https://www.bugherd.com/projects/163588/tasks/482*/      
      
  }
/*[END-ADD][STG:Bojana 6/6/2019] https://gitlab.com/medicalrecords/medicalrecords-web/issues/32*/       
  
	/*[END-ADD][STG:Bojana 5/10/2019]*/
 
   });
  
 
 
})( jQuery );

/*HideNavandFooter of Default Template*/

var image = document.querySelector("#page-id-474402 img#logo");

if ( image )
{
	image.src = "/wp-content/uploads/2019/02/Health-Insurance-Quotes-logo.svg";
}

/*HideNavandFooter of Default Template*/