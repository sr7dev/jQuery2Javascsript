
/*HideNavandFooter of Default Template*/
var image = document.querySelector("#page-id-474402 img#logo");

if ( image )
{
	image.src = "/wp-content/uploads/2019/02/Health-Insurance-Quotes-logo.svg";
}
/*HideNavandFooter of Default Template*/
